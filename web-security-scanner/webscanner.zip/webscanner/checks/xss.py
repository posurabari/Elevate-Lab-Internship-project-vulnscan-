# checks/xss.py
import requests
from bs4 import BeautifulSoup

PAYLOADS = ['"><svg/onload=alert(1)>', "'\"><img src=x onerror=alert(1)>"]

def test_xss(url, form):
    action = form.get("action") or url
    method = (form.get("method") or "get").lower()
    inputs = form.find_all(["input", "textarea"])
    name_fields = [i.get("name") for i in inputs if i.get("name")]
    vulns = []
    for p in PAYLOADS:
        data = {n: p for n in name_fields}
        try:
            r = requests.get(action, params=data, timeout=10) if method=="get" \
                else requests.post(action, data=data, timeout=10)
            if p in r.text:  # reflected
                vulns.append({
                    "type":"XSS", "evidence":"payload reflected in response",
                    "payload": p, "url": r.url, "severity":"High"
                })
        except Exception:
            pass
    return vulns
