# checks/sqli.py
import re, requests

ERRORS = re.compile(r"(SQL syntax|mysql_fetch|ORA-|SQLite/JDBC|ODBC|postgres|sql error)",
                    re.IGNORECASE)
INJ = ["' OR '1'='1", "';", "\";", "')--", "' OR 1=1 -- "]

def test_sqli(url, form):
    action = form.get("action") or url
    method = (form.get("method") or "get").lower()
    fields = [i.get("name") for i in form.find_all(["input","textarea"]) if i.get("name")]
    vulns = []
    for inj in INJ:
        data = {f: inj for f in fields}
        try:
            r = requests.get(action, params=data, timeout=10) if method=="get" \
                else requests.post(action, data=data, timeout=10)
            if ERRORS.search(r.text):
                vulns.append({
                    "type":"SQLi", "evidence":"DB error message",
                    "payload": inj, "url": r.url, "severity":"High"
                })
        except Exception:
            pass
    return vulns
