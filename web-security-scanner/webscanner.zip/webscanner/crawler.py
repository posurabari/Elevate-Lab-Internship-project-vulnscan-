# crawler.py
import requests, re
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

def same_domain(seed, link):
    return urlparse(seed).netloc == urlparse(link).netloc

def get_links(url):
    try:
        html = requests.get(url, timeout=10).text
    except Exception:
        return []
    soup = BeautifulSoup(html, "lxml")
    links = [urljoin(url, a.get("href")) for a in soup.find_all("a", href=True)]
    return [l.split("#")[0] for l in links if l.startswith("http")]

def get_forms(url):
    try:
        html = requests.get(url, timeout=10).text
    except Exception:
        return []
    soup = BeautifulSoup(html, "lxml")
    return soup.find_all("form")

def iter_site(start, max_pages=30):
    seen = set([start]); queue = [start]
    while queue and len(seen) < max_pages:
        u = queue.pop(0); yield u
        for l in get_links(u):
            if l not in seen and same_domain(start, l):
                seen.add(l); queue.append(l)
