# scanner.py
from crawler import iter_site, get_forms
from checks.xss import test_xss
from checks.sqli import test_sqli

def scan_site(start_url, max_pages=20):
    findings = []
    for page in iter_site(start_url, max_pages=max_pages):
        for f in get_forms(page):
            findings += test_xss(page, f)
            findings += test_sqli(page, f)
    return findings
