from flask import Flask, request, render_template_string
import requests

app = Flask(__name__)

# 🎨 Modern HTML template with Bootstrap
HTML_FORM = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Vulnerability Scanner</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0f172a; color: #e2e8f0; font-family: Arial, sans-serif; }
        .container { max-width: 700px; margin-top: 80px; }
        .card { border-radius: 15px; }
        h2 { color: #38bdf8; font-weight: bold; }
        .btn-scan { background: #38bdf8; border: none; }
        .btn-scan:hover { background: #0ea5e9; }
        pre { background: #1e293b; padding: 15px; border-radius: 10px; color: #f8fafc; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card p-4 shadow-lg">
            <h2 class="text-center mb-4">🔍 Web Vulnerability Scanner</h2>
            <form method="POST" class="d-flex">
                <input type="text" name="url" placeholder="Enter Target URL" class="form-control me-2" required>
                <button type="submit" class="btn btn-scan">Scan</button>
            </form>

            {% if result %}
            <hr>
            <h4>✅ Scan Result:</h4>
            <pre>{{ result }}</pre>
            {% endif %}
        </div>
    </div>
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    if request.method == "POST":
        url = request.form.get("url")
        result = run_scanner(url)
    return render_template_string(HTML_FORM, result=result)

# 🛡 Simple scanner logic
def run_scanner(url):
    findings = []
    try:
        r = requests.get(url, timeout=5)
        if "<script>" in r.text.lower():
            findings.append("⚠️ Possible XSS vulnerability detected!")
        if "sql" in r.text.lower():
            findings.append("⚠️ Possible SQL Injection pattern found!")
    except Exception as e:
        findings.append(f"❌ Error: {str(e)}")

    return "\n".join(findings) if findings else "No major issues found!"

if __name__ == "__main__":
    app.run(debug=True)
